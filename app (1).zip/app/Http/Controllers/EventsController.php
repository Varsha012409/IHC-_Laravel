<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\{
  category,
  venue,
  events,
  user
};

class EventsController extends Controller
{
  public function category()
  {
    return view('category');
  }
  public function categorystore(Request $request)
  {
    $category = new category(); {
      $category->name = $request->category;
      $category->save();
      return view('category', ['category' => $category]);
    }
  }
  public function venue()
  {
    return view('venue');
  }
  public function venuestore(Request $request)
  {
    $venue = new venue(); {
      $venue->name = $request->venue;
      $venue->save();
      return view('venue', ['venue' => $venue]);
    }
  }
  public function eventsform()
  {
    $events = events::all();
    $users = User::all();
    $category = category::all();
    $venue = venue::all();
    return view('eventsform', ['users' => $users, 'category' => $category, 'venue' => $venue, 'events' => $events]);
  }
  public function events()
  {
    $events = events::all();
    $category = category::all();
    $venue = venue::all();
    // $events = events::where('status', '=', 0)->get();
    return view('events', ['category' => $category, 'venue' => $venue, 'events' => $events]);
  }
  public function eventsstore(Request $request, events $events)
  {
    $events = new events();
    $request->validate([
      'title' => 'required|string|max:255',
      'description' => 'required|string|max:1999',
      'from_date' => 'required|date',
      'to_date' => 'required|date',
      'category_id' => 'required|exists:category,id',
      'venue_id' => 'required|exists:venue,id',
    ]);
    // dd($request->all);
    $events->title = $request->title;
    $events->description = $request->description;
    $events->from_date = $request->from_date;
    $events->to_date = $request->to_date;
    $events->category_id = $request->category_id;
    $events->venue_id = $request->venue_id;
    $events->created_by = auth()->user()->id;
    $events->updated_by = auth()->user()->id;
    $events->Status = 0;
    $events->save();
    return redirect()->route('eventsform');
  }
  public function eventsedit($id)
  {
    $events = events::findOrFail($id);
    $venue = venue::all();
    $users = User::all();
    $category = category::all();
    return view('eventsupdate', ['events' => $events, 'venue' => $venue, 'users' => $users, 'category' => $category]);
  }
  public function eventsupdate(Request $request, $id)
  {
    $request->validate([
      'title' => 'required|string|max:255',
      'description' => 'required|string|max:1999',
      'from_date' => 'required|date',
      'to_date' => 'required|date',
      'category_id' => 'required|exists:category,id',
      'venue_id' => 'required|exists:venue,id',
      //  'status' => 'required|in:0,1',
    ]);
    $events = events::findOrFail($id);
    $events->title = $request->title;
    $events->description = $request->description;
    $events->from_date = $request->from_date;
    $events->to_date = $request->to_date;
    $events->venue_id = $request->venue_id;
    $events->updated_by = auth()->user()->id;
    $events->status = $request->status;
    // dd($request->status);
    $events->save();
    return redirect()->route('events')->with('success', 'Record updated!');
  }
  public function programmes($daterange = null, $category_id = null)
  {
    $category = category::all();
    $venue = venue::all();
    $events = events::all();
    $eDate = date("Y-m-d", $daterange);
    if ($eDate && strtotime($eDate) > strtotime("2010-01-01")) {
      $start_date = $eDate;
    } else {
      $start_date = date("Y-m-d");
    }
    
    $end_date = date("Y-m-d", strtotime("$start_date + 6 days"));
    $events = events::query();

    $events->where(function ($query) use ($start_date, $end_date) {
      $query->whereBetween('from_date', [$start_date, $end_date]);
      $query->orWhereBetween('to_date', [$start_date, $end_date]);
      $query->orWhere(function ($subquery) use ($start_date) {
        $subquery->where('from_date', '<=', $start_date)->where('to_date', '>=', $start_date);
      });
      $query->orWhere(function ($subquery) use ($end_date) {
        $subquery->where('from_date', '<=', $end_date)->where('to_date', '>=', $end_date);
      });
    });

    if ($category_id && $category_id != '0') {
      $events->where('category_id', $category_id);
    }
    $events->orderBy('from_date', 'asc');
    $filteredEvents  = $events->get();

    return view('programmes', [
      'category' => $category, 'venue' => $venue, 'filteredEvents' => $filteredEvents, 'daterange' => $daterange
    ]);
  }
}
