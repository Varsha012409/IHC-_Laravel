<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\book;

class BookController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:user');
    }
    public function form()
    {
        
        return view('form');
    }

    public function storebook(Request $request)
    {
        $model = new book();
        $model->title = $request->title;
        $model->author = $request->author;
        $model->description = $request->description;
        $model->publish_date = $request->publish_date;
        $model->save();

        return view('view', ['model' => $model]);
    }

    public function book()
    {
        $model = book::all();
        return view('books', ['model' => $model]);
    }

    public function edit($id)
    {
        $model = book::find($id);
        return view('update', ['model' => $model]);
    }

    public function update(Request $request, $id)
    {
        // $request->validate([
        //     'Title' => 'required|max:255',
        //     'Author' => 'required|max:255',
        //     'Description' => 'required|max:755',
        //     'Publish Date' => 'required|date|date_format:Y-m-d',
        // ]);
        $model = book::findOrFail($id);
        $model->title = $request->title;
        $model->author = $request->author;
        $model->description = $request->description;
        $model->publish_date = $request->publish_date;
    
       
        $model->save();
        return redirect()->route('books');
    }

    public function delete($id)
    {
        $model = book::findOrFail($id);
        $model->delete();
        return view('delete',['model' => $model]);
    }

   
}
