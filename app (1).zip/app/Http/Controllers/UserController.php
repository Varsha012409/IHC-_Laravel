<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\{
  Roles,
  roles_user,
  User
};
use Illuminate\Http\Request;

class UserController extends Controller
{

  public function __construct()
{
  $this->middleware('auth');
  $this->middleware('role:admin');
}
  public function userform()
  {
    $roles = Roles::all();
    return view('auth/userform', ['roles' => $roles]);
  }
  public function userstore(Request $request, Roles $roles)
  {
    $users = new user();
    $request->validate([
      'name' => 'required|string|max:250',
      'email' => 'required|email|max:250|unique:users',
      'password' => 'required|min:8|confirmed',
    ]);
    //saving in users
    User::create([
      'name' => $request->name,
      'email' => $request->email,
      'password' => Hash::make($request->password),
    ]);

    $roles->user_id = request()->user()->id;
    $users->roles()->attach($request->input('roles'));
    return view('auth/userview', ['user' => $users]);
  }
  public function register()
  {
    $roles = Roles::all();
    $users = User::all();
    // $users = User::find(1);

    return view('auth/register', ['users' => $users, 'roles' => $roles]);
  }

  public function useredit($id)
  {
    $users = User::findOrFail($id);
    return view('auth/userupdate', ['user' => $users]);
  }
  public function userupdate(Request $request, $id)
  {
    $user = user::findOrFail($id);
    $user->name = $request->name;

    if ($request->password) {
      $user->password = $request->password;
      $user->save();
    }
    return redirect()->route('register');
  }

  public function userdelete($id)
  {
    $user = user::findOrFail($id);
    $user->delete();
    return view('auth/userdelete', ['user' => $user]);
  }

  public function createrole()
  {
    return view('auth/createrole');
  }

  public function storerole(Request $request, Roles $roles, User $users)
  {
    $request->validate([
      'role' => 'required|string|max:255',
    ]);
    $roles->name = $request->role;
    $users->roles()->attach($request->input('roles'));
    $roles->save();
    return view('auth/createrole');
  }

  public function showRoleUserForm($userid)
  {

    $roles = Roles::all();
    $user = User::find($userid);
    return view('auth/roleuser', ['roles' => $roles, 'user' => $user]);
  }
  public function saveRoleUser(Request $request, $userid)
  {

    if ($request->roleaction === 'assign') {
      $isexist = roles_user::where('user_id', $userid)->where('roles_id', $request->roles)->count();
      if ($isexist == 0) {
        $roleuser = new roles_user();
        $roleuser->user_id = $userid;
        $roleuser->roles_id = $request->roles;
        $roleuser->save();
      }
      return redirect()->route('register')->with('success', 'Role assigned successfully');
    } elseif ($request->roleaction === 'remove') {
      $roleuser = roles_user::where('user_id', $userid)->where('roles_id', $request->roles)->first();
      if ($roleuser) {
        $roleuser->delete();
        return redirect()->route('register')->with('success', 'Role assigned successfully');
      }
    }
    return redirect()->route('register')->with('error', 'Something went wrong');
  }



}
