<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class AuthController extends Controller
{
  public function __construct()
  {
      $this->middleware('guest');
  }
 
   public function loginform() 
  {
    return view('auth/login');
  }

  public function login(Request $request) 
  {
 
    $credentials = $request->validate([
      'email' => 'required|email',
      'password' => 'required'
  ]);
  
  if(Auth::attempt($credentials))
  {
      return redirect()->route('welcome')
          // ->withSuccess('You have successfully logged in!');
          ;
  }

  return back()->withErrors([
      'email' => 'Your provided details do not match in our records.',
  ])->onlyInput('email');

  }

  
//   public function registration() 
//   {
//     return view('auth/registration');
//   }

//   public function register(Request $request) 
//   {
//     $request->validate([
//       'name' => 'required|string|max:250',
//       'email' => 'required|email|max:250|unique:users',
//       'password' => 'required|min:8|confirmed'
//   ]);
// //saving in users
//   User::create([
//       'name' => $request->name,
//       'email' => $request->email,
//       'password' => Hash::make($request->password)
//   ]);
//    if(Auth::attempt($request->only ('email','password')))
//   {
//       return redirect()->route('welcome');
//   }

//  return redirect('register')->withError('Error');
//    }

 
}
