<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\book;
use Illuminate\Support\Facades\Auth;

class SiteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {

        return view('welcome');
        // return view('register');
    }
    public function logout() 
  {
    // die();

   Auth::logout();
   return redirect('/');

 }
}
