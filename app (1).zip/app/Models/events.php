<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class events extends Model
{
    use HasFactory;
    protected $table = 'events';

    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'title',
        'description',
    	'from_date',
    	'to_date',
    	'category_id',
    	'venue_id',
    	'created_by',
    	'updated_by',
        'Status'
    ];
    public function users()
    {
        return $this->belongsTo(User::class);
    }
    public function category()
    {
        return $this->belongsTo(category::class);
    }
    public function venue()
    {
        return $this->belongsTo(venue::class);
    }

}
