@extends('layouts/layout')
    
    @section('title','Delete')

    @section('header','Delete!')

  @section('content')

  <p>Are you sure you want to delete the details <strong>Title</strong> {{$model->title}}
    <strong>Author</strong> {{$model->author}} <strong>Description </strong>{{$model->description}}
    <strong>Publish Date </strong>{{$model->publish_date}}
    ?</p>


  <form method="get" action="{{Route('books', ['id' => $model->id])}}">

    @csrf
    <button type="submit" href=" " class="btn btn-danger">Delete</button>
    <a href="{{ route('books') }}" class="btn btn-secondary">Cancel</a>

    {{-- <a href="{{ route('books')}}" class="btn btn-secondary">Cancle</a> --}}
</form>



  @endsection