@extends('layouts/layout')

@section('title','Events Form')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card-header">{{ __('New Events ') }}</div>

            <div class="card-body">
                <form action="{{Route('eventsstore')}}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="title">{{ __('Title') }}</label>
                        <input id="tite" type="text" class="form-control @error('title') is-invalid @enderror" name="title" value="{{ old('title') }}" required autocomplete="title" autofocus>
                        @error('title')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="description">{{ __('Description') }}</label>
                        <textarea  id="description" class="form-control @error('description') is-invalid @enderror" name="description" value="{{ old('description')}}" required autocomplete="descriptions"  rows="5"></textarea>
                       
                        @error('description')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="from_date">{{ __('From Date') }}</label>
                        <input id="from_date" type="datetime-local" class="form-control @error('from_date') is-invalid @enderror" name="from_date" value="{{old('from_date')}}" required autocomplete="from_date">
                        @error('from_date')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="to_date">{{ __('To Date') }}</label>
                        <input id="to_date" type="datetime-local" class="form-control @error('to_date') is-invalid @enderror" name="to_date" value="{{old('to_date')}}" required autocomplete="to_date">
                        @error('to_date')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>

                  <div class="form-group">
                        <label for="category_id">{{ __('Category Id') }}</label>
                        <select name="category_id" class="form-control">
                            @foreach($category as $category)
                            <option value="{{$category->id}}">{{$category->name}}</option>
                            @endforeach
                        </select>
                    </div>
                  
                    <div class="form-group">
                        <label for="venue_id">{{ __('Venue Id') }}</label>
                        <select name="venue_id" class="form-control">
                            @foreach($venue as $venue)
                            <option value="{{$venue->id}}">{{$venue->name}}</option>
                            @endforeach
                        </select>
                    </div>
                  
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            {{ __('Save') }}
                        </button>
                    </div> 
                </form>
            </div>
        </div>
    </div>
</div>
@endsection