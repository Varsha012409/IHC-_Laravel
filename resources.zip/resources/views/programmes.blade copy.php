@extends('layouts/eventslayout')

@section('title', 'programmes')

{{-- @section('header', 'Users!') --}}
@section('content')
    <div class="container maincontainer">
        <div class="row">
            {{-- <div class="col-12"> --}}

            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
                        aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                        aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                        aria-label="Slide 3"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3"
                        aria-label="Slide 4"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4"
                        aria-label="Slide 5"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="{{ asset('images/prg2.jpg') }}" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="{{ asset('images/prg.jpg') }}" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="{{ asset('images/prg3.jpg') }}" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="{{ asset('images/prg6.jpg') }}" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="{{ asset('images/prg7.jpg') }}" class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon " aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            
            <form method="POST">
                @csrf
                <div class="container searchcoloumn ">
                    <select id="year" name="year">
                        @for ($year = date('Y'); $year >= 2014; $year--)
                            <option value="{{ $year }}"
                                {{ $year == date('Y', $daterange) ? 'selected' : '' }}>{{ $year }}
                            </option>
                        @endfor
                    </select>
                    <select id="month" name="month">
                        <option value="0">SELECT MONTH</option>
                        @for ($month = 1; $month <= 12; $month++)
                            <option value="{{ $month }}"
                                {{ $month == date('n', $daterange) ? 'selected' : '' }}>{{ date("F", strtotime("2023-$month-1")) }}
                            </option>
                        @endfor
                    </select>
                    <select id="category_id" name="category_id">
                        <option value="0">All Event</option>
                        @foreach ($category as $category)
                            <option value="{{ $category->id }}"
                                {{ $category->id == request('category_id') ? 'selected' : '' }}>{{ $category->name }}
                            </option>
                        @endforeach
                    </select>

                    <a href="#" id="search"><i class="fas fa-search fa-2x searchicon"></i></a>
                    {{-- <button type="submit">seacrch</button> --}}
                    <div>
                        <h4>{{ date('F', $daterange) }}:</h4>

                    </div>

            </form>
        </div>

        <div class="col-md ">
            <h4 class="eventcalendar">Calendar of Event
                ({{ date('d', $daterange) }}-{{ date('d M,Y', strtotime(date('Y-m-d', $daterange) . " + 6 days")) }})
            </h4>
            <div class="line"></div>
        </div>
        <div class="col-md-2 icons">
            {{-- <a href="{{ route('programmes')}}"><i class="fas fa-arrow-left fa-2x "></i></a> --}}
            <a href="{{ route('programmes') }}" id="leftarrowevents"><i class="fas fa-arrow-left fa-2x "></i></a>
            |
            <a href="{{ route('programmes') }}"><i class="fas fa-home fa-2x"></i></a>
            |
            <a href="{{ route('programmes') }}" id="rightarrowevents"><i class="fas fa-arrow-right fa-2x"></i></a>
        </div>
        <hr>
        <div class="col-12">
            
            @if ($filteredEvents->isEmpty())
                <p>No results found.</p>
            @else
                <ul>
                    @foreach ($filteredEvents as $events)
                        <div class="col-md calender">
                            <span class="day">
                                {{ date('d D', strtotime($events->from_date)) }}
                            </span>
                            <span class="dte">
                                {{ date('M,Y', strtotime($events->from_date)) }}
                            </span>
                        </div>
                        <ul class="evts">
                            <strong>{{ $events->title }}</strong>-{{ $events->description }}

                            {{-- @php
          $parts = explode('-', $events->description, 2);
          $title = isset($parts[0]) ? trim($parts[0]) : '';
          $description = isset($parts[1]) ? trim($parts[1]) : '';
      @endphp --}}
                            {{-- {{ $events->title }}{{ $events->description }} --}}
                            <br>
                            <Strong>Venue:</Strong>
                            <label for="{{ $events->venue->id }}"
                                class="col-sm-2 col-form-label">{{ $events->venue->name }}</label>
                            <br>

                            @if (date('Y-m-d', strtotime($events->from_date)) == date('Y-m-d'))
                                <i class="fas fa-clock"></i>
                                {{ date('H:i') }}
                            @else
                                <i class="fas fa-calendar"></i>
                                {{ date('M d, Y', strtotime($events->from_date)) }} -
                                {{ date('M d, Y', strtotime($events->to_date)) }}
                            @endif
                        </ul>
                </ul>
                <hr>
            @endforeach
            @endif
        </div>
    </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#search').on('click', function(e) {
                e.preventDefault();
                var year = $('#year').val();
                var month = $('#month').val();
                var date = new Date();
                if(year > 2013 && month > 0){
                    date = new Date(year, month - 1, 01);
                }                
                var daterange = Math.floor(date.getTime() / 1000);
                var url =
                    "{{ route('programmes', ['daterange' => ':daterange', 'category_id' => ':category_id']) }}";
                url = url.replace(':daterange', daterange).replace(':category_id', $('#category_id').val());
                window.location.href = url;
            });
        });


    </script>
@endsection
