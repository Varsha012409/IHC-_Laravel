@extends('layouts/layout')

@section('title', 'Events')

@section('header', 'Events!')
@section('content')

    <table border="1" class="table table-striped">
        <tr>
            <td colspan="2"><a href="{{ Route('eventsform') }}" class="btn btn-warning">New form</a></td>
            <td ><a href="{{ Route('category') }}" class="btn btn-warning">New Category</a></td>
            <td colspan="4"><a href="{{ Route('venue') }}" class="btn btn-warning">New Venue</a></td>
        </tr>
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Description</th>
            <th>From Date</th>
            <th>To Date</th>
            <th>Category </th>
            <th>Venue </th>
            {{-- <th>Created By</th>
            <th>Updated By</th> --}}
            <th>Update</th>
            <th>Status</th>


        </tr>
       

        @foreach ($events as $events)
            <tr>
                <td>{{ $events->id }}</td>
                <td>{{ $events->title }}</td>
                <td>{{ $events->description }}</td>
                <td>{{$events->from_date}}</td>
                <td>{{ $events->to_date }}</td>
                 <td>
                <label for="color{{  $events->category_id }}" class="col-sm-2 col-form-label">{{ $events->category->name }}</label>
                </td>    
                <td>
                        <label for="color{{ $events->venue->id }}" class="col-sm-2 col-form-label">{{ $events->venue->name }}</label>
                </td>
                <td><a href="{{ Route('eventsedit', ['id' => $events->id]) }}" class="btn btn-primary ">Update</a></td>
                <td>
                    @if($events->status == '0')
                    <span class="text-success">Active</span>
                @else
                    <span class="text-danger">Inactive</span>
                @endif
                </td>
            <td>
          
            </td>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
