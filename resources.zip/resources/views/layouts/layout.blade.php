<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <style>
    table, th, td {
  border:1px solid white;
  color: white;
}

      </style>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.min.css')}}">

</head>
<body style=" color:white; background-color: rgb(41, 41, 41)";>
    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div class="container-fluid">
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
               @if (Route::has('login'))
                @auth
                {{-- <a href="{{ url('/home') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a> --}}
                        <li class="nav-item">
                          <a class="nav-link active" aria-current="page" href="{{Route('welcome')}}">Home</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="{{Route('books')}}">Books</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="{{Route('form')}}"> New Form</a>
                        </li>     
                        <li class="nav-item">
                          <a class="nav-link active" href="{{Route('logout')}}"> Logout</a>
                        </li>     
                        @if (Route::has('register'))
                        <li class="nav-item"> <a href="{{Route('register') }}" class="nav-link active ">Users</a>
                        </li>
                      </li>     
                      {{-- <li class="nav-item">
                        <a class="nav-link active" href="{{Route('category')}}">Category</a>
                      </li>    
                      <li class="nav-item">
                        <a class="nav-link active" href="{{Route('venue')}}">Venue</a>
                      </li>    --}}
                      <li class="nav-item">
                        <a class="nav-link active" href="{{Route('events')}}">Events</a>
                      </li>   
                     @endif
                    @else
                        <li class="nav-item"><a href="{{Route('login') }}" class="nav-link active">Log in</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link active" href="{{Route('programmes')}}">Programmes</a>
                        </li>  
                    @endauth
            @endif
            </ul>
          </div>
        </div>
      </nav>
      
    <div class="container-xl">
      
    <header>
       @yield('header')
    </header>
    <div class="content">
        @yield('content')
    </div>
    <footer>
        
    </footer>
    
    
    <script src="{{asset('bootstrap/js/bootstrap.bundle.min.js')}}"></script>
</div>
</body>
</html>