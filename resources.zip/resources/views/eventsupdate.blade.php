@extends('layouts/layout')

@section('title', 'Update Events')

@section('header', 'Update Events')
@section('content')

    <form action="{{ Route('eventsupdate', ['id' => $events->id]) }}" method="POST">

        <table class="table">
            @csrf
            <tr>
                <th>Title</th>
                <td>
                    <input type="text" id="title" class="form-control" name="title" value="{{ $events->title }}">
                </td>
            </tr>
            <tr>
                <th>Description</th>
                <td>
                    <textarea type="text" id="description" class="form-control" name="description" value="{{ $events->description }}">{{ $events->description }}</textarea>

                </td>
            </tr>
            <tr>
                <th>From Date</th>
                <td>
                    <input type="datetime-local" id="from_date" class="form-control" name="from_date"
                        placeholder="from_date" value="{{ $events->from_date }}">
                </td>
            </tr>
            <tr>
                <th>To Date</th>
                <td>
                    <input type="datetime-local" id="to_date" class="form-control" name="to_date" placeholder="to_date"
                        value="{{ $events->to_date }}">
                </td>
            </tr>
            <tr>

                <th>Category</th>
                {{-- <label for="category_id">{{ __('Category Id') }}</label> --}}
                <td> <select name="category_id" class="form-control">
                        @foreach ($category as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>

                </td>
            </tr>
            <tr>
                <th>Venue </th>
                <td>
                    <select name="venue_id" class="form-control">
                        @foreach ($venue as $venue)
                            <option value="{{ $venue->id }}">{{ $venue->name }}</option>
                        @endforeach
                    </select>
                </td>
            </tr>
            <tr> 
                <td colspan="2">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="0" value="0"
                            {{ $events->status == '0' ? 'checked' : '' }}>
                        <label class="form-check-label" for="0">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="1" value="1"
                            {{ $events->status == '1' ? 'checked' : '' }}>
                        <label class="form-check-label" for="1" id="inactive">Inactive</label>
                    </div>
                    @error('roleaction')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </td>
            </tr>

            <tr>
                <td colspan="2"> <input type="submit" value="Update" class="btn btn-primary"> </td>
            </tr>

        </table>

    </form>

@endsection
