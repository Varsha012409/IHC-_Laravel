@extends('layouts/layout')
    
    @section('title','Form')
   

    @section('header','Insert!')

  @section('content')

 
  <form action="{{Route('storebook')}}" method="POST">
    <table class="table table-striped">
        @csrf
         <tr>
             <th >Title</th>
             <td><input type="text" name="title" class="form-control" placeholder="Title"></td>
         </tr>  
         <tr>
             <th >Author</th>
             <td> <input type="text" name="author"  class="form-control" placeholder="Author"></td>
         </tr>
         <tr>
             <th>Description</th>
             <td><input type="text" name="description"  class="form-control form-control-lg" placeholder="Description"></td>
         </tr>
         <tr>
             <th>Publish Date</th>
             <td><input type="date" name="publish_date"  class="form-control" placeholder="Publish Date"></td>
         </tr>
    
         <tr>
             <td colspan="5"> <input type="submit" value="Save" class="btn btn-primary"> </td>            
         </tr>
     </table>            

    </form>

  @endsection
