@extends('layouts/layout')

@section('title','Update')

@section('header','Update')
@section('content')

<form action="{{Route('update', ['id' => $model->id])}}" method="POST">
   
    <table class="table">
        @csrf
        <tr>
            <th >Title</th>
            <td>
                <input type="text" id="title" class="form-control" name="title" value="{{$model->title}}">
            </td>
        </tr>  
        <tr>
            <th >Author</th>
            <td>
                <input type="text" id="author" class="form-control" name="author" placeholder="Author" value="{{$model->author}}">
            </td>
        </tr>
        <tr>
            <th>Description</th>
            <td>
                <input type="text" id="description" class="form-control" name="description" placeholder="Description" value="{{$model->description}}">
            </td>
        </tr>
        <tr>
            <th>Publish Date</th>
            <td>
                <input type="date" id="publish_date" name="publish_date" class="form-control" placeholder="Publish Date" value="{{$model->publish_date}}">
            </td>
        </tr>
           
            
        </tr>
        <tr>
            <td colspan="2"> <input type="submit" value="Update" class="btn btn-primary"> </td>            
        </tr>
    </table>            

   </form>

@endsection