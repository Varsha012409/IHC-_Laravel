@extends('layouts/layout')

@section('title','Update')

@section('header','Update')
@section('content')

<form action="{{Route('userupdate', ['id' => $user->id])}}" method="POST">
   
    <table class="table">
        @csrf
        <tr>
            <th >Name</th>
            <td>
                <input type="text" id="name" class="form-control" name="name" placeholder="Name" value="{{$user->name}}">
            </td>
        </tr>  
        <tr>
            <th >E-mail</th>
            <td>
                {{$user->email}}
            </td>
        </tr>
        <tr>
            <th>Password</th>
            <td>
                <input type="password" id="password" class="form-control" name="password" placeholder="Password">
               
            </td>
        </tr>          
        </tr>
        <tr>
            <td colspan="2"> <input type="submit" value="Update" class="btn btn-primary"> </td>            
        </tr>
    </table>            

   </form>
   
    


@endsection