@extends('layouts/layout')

@section('title','Created')

@section('header','Successfully Created!')

@section('content')
 <table border="1" class="table table-striped">
    @csrf
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>E-mail</th>
        <th>Password</th>
        {{-- <th>Publish Date</th> --}}
    </tr>
    <tr>
        <td>{{$user->id}}</td>
        <td>{{$user->name}}</td>
        <td>{{$user->email}}</td>
    </tr>
    <tr>
       <td colspan="3"><a  class="btn btn-warning" href="{{Route('userform')}}">New User</a> 
        
       {{-- <td colspan="2"> <button href="{{Route('books')}}" class="btn btn-primary" >Books</button></td>
       --}}
    </tr>
 </table>
@endsection