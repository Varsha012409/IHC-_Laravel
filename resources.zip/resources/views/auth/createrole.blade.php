@extends('layouts/layout')
    
    @section('title','Form')
   

    @section('header','Insert!')

  @section('content')

 
  <form action="{{Route('storerole')}}" method="POST">
    <table class="table table-striped">
        @csrf
         <tr>
             <th >Role</th>
             <td><input type="text" name="role" class="form-control" placeholder="role">
                @error('role')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $role }}</strong>
                                </span>
                            @enderror</td>
         </tr>  
        
             <td colspan="5"> <input type="submit" value="Save" class="btn btn-primary"> </td>            
         </tr>
     </table>            

    </form>

  @endsection