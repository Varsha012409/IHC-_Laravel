@extends('layouts/layout')

@section('title','Register')

@section('content')


<form id="logout-form" action="{{ route('logout') }}" method="POST" >
        @csrf
        {{-- <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a> --}}
</form>

@endsection