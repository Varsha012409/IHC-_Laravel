@extends('layouts/layout')

@section('title', 'Books')

@section('header', 'Users!')
@section('content')

    <table border="1" class="table table-striped">
        <tr>
            <td colspan="3"><a href="{{ Route('userform') }}" class="btn btn-warning">New User</a></td>
            <td colspan="4"><a href="{{ Route('createrole') }}" class="btn btn-warning">Newrole</a></td>
        </tr>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>E-mail</th>
            {{-- <th>Password</th> --}}
            <th>Role</th>
            <th>Update</th>
            <th>Action</th>
            <th>Delete</th>


        </tr>
        @foreach ($users as $user)
            <tr>
                <td>{{ $user->id }}</td>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                {{-- <td>{{$user->password}}</td> --}}
                <td>
                    @foreach ($user->roles as $role)
                        {{ $role->name }}
                    @endforeach
                </td>
                <td><a href="{{ Route('useredit', ['id' => $user->id]) }}" class="btn btn-primary ">Update</a></td>
                <td><a href="{{ Route('roleuser', ['id' => $user->id]) }}" class="btn btn-success ">Role</a></td>
                <td><a href="{{ route('userdelete', ['id' => $user->id]) }}" class="btn btn-danger">Delete</a>

                </td>
            </tr>
        @endforeach
    </table>
@endsection
