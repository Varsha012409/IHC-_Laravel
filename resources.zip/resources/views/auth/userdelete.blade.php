@extends('layouts/layout')
    
    @section('title','Delete')

    @section('header','Delete!')

  @section('content')

  <p>Are you sure you want to delete the details <strong>Name</strong> {{$user->name}}
    <strong>Author</strong> {{$user->email}} <strong>Description </strong>{{$user->email}}
    <strong>Publish Date </strong>{{$user->password}}
    ?</p>


  <form method="get" action="{{Route('register', ['id' => $user->id])}}">

    @csrf
    <button type="submit" href=" " class="btn btn-danger">Delete</button>
    {{-- <a href="{{ route('books') }}" class="btn btn-secondary">Cancel</a> --}}

</form>



  @endsection