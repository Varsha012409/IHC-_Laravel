@extends('layouts/layout')
    
    @section('title','Venue')
   

    @section('header','Insert!')

  @section('content')

 
  <form action="{{Route('venuestore')}}" method="POST">
    <table class="table table-striped">
        @csrf
         <tr>
             <th >Venue</th>
             <td>
                <input type="text" name="venue" class="form-control" placeholder="venue">
                @error('venue')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $venue }}</strong>
                                </span>
                            @enderror
            </td>

         </tr>  
        
             <td colspan="5"> <input type="submit" value="Save" class="btn btn-primary"> </td>            
         </tr>
     </table>            

    </form>

  @endsection