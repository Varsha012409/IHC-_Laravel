@extends('layouts/layout')
    
    @section('title','Category')
   

    @section('header','Insert!')

  @section('content')

 
  <form action="{{Route('categorystore')}}" method="POST">
    <table class="table table-striped">
        @csrf
         <tr>
             <th >Category</th>
             <td>
                <input type="text" name="category" class="form-control" placeholder="category">
                @error('category')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $category }}</strong>
                                </span>
                            @enderror
            </td>

         </tr>  
        
             <td colspan="5"> <input type="submit" value="Save" class="btn btn-primary"> </td>            
         </tr>
     </table>            

    </form>

  @endsection