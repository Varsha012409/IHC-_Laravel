@extends('layouts/layout')

@section('title','Books')

@section('header','Books!')
@section('content')

    <table border="1" class="table table-striped">
        <tr>
          <th>Id</th>
          <th>Title</th>
          <th>Author</th>
          <th>Description</th>
          <th>Publish Date</th>
          <th>Update</th>
          <th>Delete</th>
        </tr>  
  @foreach ($model as $book)
  <tr>
      <td>{{$book->id}}</td>
      <td>{{$book->title}}</td>
      <td>{{$book->author}}</td>
      <td>{{$book->description}}</td>
      <td>{{$book->publish_date}}</td>
   <td><a href="{{Route('edit', ['id' => $book->id]) }}">Update</a>

    <td><a href="{{ route('delete', ['id' => $book->id])}}" class="btn btn-danger">Delete</a>
</td>
  </tr>
  @endforeach
      </table>
@endsection