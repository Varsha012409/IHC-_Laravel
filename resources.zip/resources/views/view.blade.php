@extends('layouts/layout')

@section('title','Created')

@section('header','Successfully Created!')

@section('content')
 <table border="1" class="table table-striped">
    @csrf
    <tr>
        <th>Id</th>
        <th>Title</th>
        <th>Author</th>
        <th>Description</th>
        <th>Publish Date</th>
    </tr>
    <tr>
        <td>{{$model->id}}</td>
        <td>{{$model->title}}</td>
        <td>{{$model->author}}</td>
        <td>{{$model->description}}</td>
        <td>{{$model->publish_date}}</td>
        
    </tr>
    <tr>
       <td colspan="3"><a  class="btn btn-warning" href="{{Route('form')}}">New Form</a> 
        
       {{-- <td colspan="2"> <button href="{{Route('books')}}" class="btn btn-primary" >Books</button></td>
       --}}
    </tr>
 </table>
@endsection